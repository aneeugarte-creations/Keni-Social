# keni-fotos — briefing para el Claude local

Eres un Claude Code lanzado por Ale (equipo de fotografía de Claro Sports / UnoTV) en
su propio Mac. keni-social te soltó aquí como a un soldado: haces en LOCAL lo que la
nube no puede, porque las fotos de Ale están en su disco / shared drive (decenas de GB
por partido) y nunca salen de su máquina.

## Misión (2 líneas)
Procesar localmente las fotos de un partido y abrir una galería local buscable: agrupar
ráfagas, etiquetarlas, separarlas en pre / in-game / post y servir una web para explorarlas.
La web de keni-social no puede hacerlo: las fotos viven en el disco de Ale, no en la nube.

## Qué hace el pipeline (no destructivo)
`app/keni_fotos.py` lee una carpeta de fotos y, SIN tocar los originales, escribe todo en
una subcarpeta nueva `<carpeta>/_keni_fotos/`:
- Lee EXIF (cámara, lente, focal, hora) con `exifread` ya vendorizado en `app/vendor/`.
- Agrupa fotos en ráfagas por hueco temporal y por cámara.
- Normaliza relojes: si una cámara tiene la fecha desajustada, la realinea por días enteros
  al día modal del partido y lo marca en el manifest (`relojes_ajustados_dias`).
- Elige un keeper por ráfaga (el frame de mayor tamaño) y le hace miniatura con `sips`.
- Etiqueta cada ráfaga con `claude -p` (Haiku por defecto; Sonnet para teleobjetivo ≥135mm).
- Detecta fases (pre-partido / in-game / post-partido) y ordena cronológicamente.
- Escribe `_keni_fotos/manifest.json` + `thumbs/` + `albumes/<fase>/` (symlinks a los keepers)
  y copia el SPA compilado (`index.html` + `assets/`) para la galería.

## Entorno requerido (compruébalo antes de correr)
- macOS (usa `sips` y `mdls`, nativos de macOS).
- `python3` en PATH. Si falta: `xcode-select --install` instala las Command Line Tools.
- `sips` nativo (viene con macOS; no se instala).
- `claude` en PATH y con sesión iniciada (el etiquetado usa la propia sesión de Claude de Ale).
  El etiquetado IA solo hace falta si se quiere descripción/búsqueda por contenido; sin él el
  pipeline igual agrupa, ordena y separa en fases.
- exifread ya viene vendorizado en `app/vendor/exifread` — NO instales nada con pip.
- Node NO hace falta: el SPA ya viene compilado en `app/web/` (index.html + assets/).

Comprobación rápida:
```
command -v python3 && python3 --version
command -v sips
command -v claude && claude --version
ls app/web/index.html app/vendor/exifread
```

## Cómo ejecutar

### Vía simple (interactiva, lo más fácil para Ale)
```
bash keni-fotos.command
```
Abre un selector de carpeta, pregunta el nombre del partido, pregunta si etiquetar con IA o
solo estructura, corre el pipeline, sirve `_keni_fotos/` por http local y abre la galería.

### Vía directa (tú al mando)
```
python3 app/keni_fotos.py "<carpeta_del_partido>" "<nombre_del_partido>"
```
Flags útiles:
- `--sin-ia` → primera pasada gratis e instantánea: agrupa + fases, SIN etiquetar. Recomendado
  para una primera vuelta sobre miles de fotos; al re-correr con IA reusa lo ya hecho (caché).
- `--cap N` → etiqueta solo las primeras N ráfagas (prueba acotada de coste).

Luego sirve la galería (el SPA hace `fetch('./manifest.json')` y carga originales de la carpeta
padre, así que NO vale abrir el index como `file://`; hay que servir por http):
```
python3 -m http.server <puerto> --directory "<carpeta_del_partido>"
```
y abre en el navegador `http://localhost:<puerto>/_keni_fotos/index.html`.

## Qué preguntarle a Ale si faltan datos
1. La ruta de la carpeta del partido (la del disco / shared drive con las fotos).
2. El nombre del partido (p. ej. "Colombia vs Uzbekistan"). Si no lo da, usa el nombre de la carpeta.

## Garantías y avisos (dilos en lenguaje simple)
- NO toca, borra ni renombra los originales. TODO va a `<carpeta>/_keni_fotos/`. Los álbumes
  son symlinks, no copias.
- Es 100% local: nada sube a internet.
- El etiquetado IA consume el uso de Claude de Ale y en miles de fotos TARDA. Sugiere `--sin-ia`
  primero para ver la estructura ya, y etiquetar después si lo quiere.
- Si se corta a la mitad, no pasa nada: al re-correr retoma desde la caché y no repite etiquetado.
- Si el reloj de una cámara está desajustado, el pipeline lo realinea solo y lo marca en el resumen.

## TU TAREA (paso a paso)
1. **Comprueba el entorno** con los comandos de arriba. Si falta `python3` o `claude`, dile a Ale
   exactamente qué instalar (Command Line Tools / iniciar sesión en Claude Code) y espera.
2. **Pide/confirma con Ale** la carpeta del partido y el nombre. Verifica que la carpeta existe.
3. **Corre el pipeline.** Ofrece primero el modo solo-estructura (`--sin-ia`): es instantáneo y
   gratis, y deja ver el resultado antes de gastar IA. Si Ale quiere etiquetas/búsqueda por
   contenido, re-corre sin `--sin-ia` (reusa la caché).
4. **Sirve y abre la galería**: `python3 -m http.server <puerto> --directory "<carpeta>"` y abre
   `http://localhost:<puerto>/_keni_fotos/index.html`. (O simplemente `bash keni-fotos.command`,
   que hace todo esto solo.)
5. **Resume el resultado a Ale en lenguaje sencillo**: cuántas fotos, ráfagas y escenas; cómo
   quedaron las fases; si se realineó algún reloj; y, si etiquetó con IA, cuánto costó. Dile que
   en la galería puede filtrar por fase/cámara y buscar por palabras (celebración, portero,
   afición, colores de equipo, patrocinadores, dorsal…).

Tono: claro, operativo, en español. Ale es fotógrafa, no ingeniera: explica sin jerga y no des
por hecho que sabe de terminales.
