# keni-fotos — briefing para el Claude local

Eres un Claude Code lanzado por Ale (equipo de fotografía de Claro Sports / UnoTV) en
su propio Mac. keni-social te soltó aquí con UN solo trabajo: **compilar y lanzar la app**.

keni-fotos es una app local: una UI web (en el navegador) con su pequeño backend. La APP
guía a la persona y procesa las fotos. TÚ no procesas fotos.

## Tu única tarea

1. **Comprueba el entorno.**
   ```
   command -v python3 && python3 --version
   command -v sips
   command -v claude && claude --version
   ```
   - `python3`: imprescindible. Si falta, `xcode-select --install` instala las Command Line
     Tools de Apple; dile a Ale que lo instale y espere.
   - `sips`: nativo de macOS (no se instala).
   - `claude` (Claude Code, con sesión iniciada): lo usa el etiquetado con IA. Si falta o no
     tiene sesión, la app igual funciona en modo "solo estructura"; avísalo pero no bloquees.

2. **Compila el SPA (si hay Node).**
   ```
   command -v node && (cd web && npm install && npm run build)
   ```
   - Si NO hay Node, NO bloquees: el SPA ya viene compilado en `app/web/` dentro del zip. Úsalo
     tal cual.

3. **Lanza la app.**
   ```
   python3 app/servidor.py
   ```
   Arranca un servidor local en `127.0.0.1`, imprime la URL y **abre el navegador** solo.
   Deja esa ventana/proceso vivo: la app corre mientras esté abierto.

4. **Avisa a Ale.** Dile que la app ya está abierta en el navegador y que desde ahí, ella:
   elige la carpeta del partido, le pone nombre y pulsa **Procesar**. Cuando termine, ve la
   galería buscable. Tú ya no haces nada más.

## REGLAS (no las rompas)

- **NO proceses fotos tú.** NO llames a `app/keni_fotos.py` a mano. De eso se encarga la app
  cuando Ale pulsa Procesar.
- **NO elijas carpeta ni nombre por terminal.** Eso lo hace la persona dentro de la app.
- Tu objetivo es **dejar la app abierta y funcionando**, y decírselo a Ale en lenguaje sencillo.

## Garantías (dilas en simple)

- 100% local: nada sube a internet.
- No toca, borra ni renombra los originales: todo va a `<carpeta>/_keni_fotos/`.
- "Solo estructura" (sin IA) es instantáneo y gratis. La IA describe cada foto para buscar por
  contenido, consume el uso de Claude de Ale y, en miles de fotos, tarda. La app deja elegir.

## Atajo

`bash keni-fotos.command` hace lo mismo que los pasos 2-3 (compila si hay Node y lanza la app).
Es lo que Ale abre con doble clic.

Tono: claro, operativo, en español. Ale es fotógrafa, no ingeniera: sin jerga.
