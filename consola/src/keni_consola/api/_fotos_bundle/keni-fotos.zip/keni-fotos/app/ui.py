"""
ui.render(manifest, out_dir) — despliega el SPA (React + Vite + shadcn, MISMO stack que
keni-social) en el directorio de salida, copiando el bundle ya compilado de `app/web/`.

El SPA es codigo fuente en `keni-fotos/web/` (migrable a keni-social) y se compila a
`app/web/` con `vite build`. Aqui solo lo copiamos junto al `manifest.json` (que escribe
keni_fotos.py) y a `thumbs/`; el SPA hace `fetch('./manifest.json')` al servirse por http
local. NO genera HTML: el look & feel viene de los componentes shadcn reales.
"""
import shutil
from pathlib import Path

WEB = Path(__file__).resolve().parent / "web"


def render(manifest, out_dir):
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    if not (WEB / "index.html").exists():
        (out_dir / "index.html").write_text(
            "<!doctype html><meta charset=utf-8><body style='font:16px system-ui;padding:40px'>"
            "<h2>Falta el bundle del SPA (app/web/).</h2>"
            "<p>Compilalo con: <code>cd keni-fotos/web &amp;&amp; npm install &amp;&amp; npm run build</code></p>",
            encoding="utf-8")
        return
    # Copia el bundle compilado (index.html + assets/) al dir de salida, junto al
    # manifest.json y thumbs/ que ya estan ahi. No toca los originales.
    for item in WEB.iterdir():
        if item.name == "manifest.json":
            continue  # nunca pisar el manifest real que escribe keni_fotos.py
        dest = out_dir / item.name
        if item.is_dir():
            shutil.copytree(item, dest, dirs_exist_ok=True)
        else:
            shutil.copy2(item, dest)
