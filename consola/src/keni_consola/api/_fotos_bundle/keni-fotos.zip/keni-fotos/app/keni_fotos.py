#!/usr/bin/env python3
"""keni-fotos: almacen fotografico ordenado y buscable a partir de rafagas.

Pipeline local (determinista + capa fina de IA), sin dependencias instalables:
  0. Ingesta EXIF        -> camara (prefijo), lente, focal, timestamp, tamano.
  1. Agrupar en rafagas  -> corte por hueco temporal > GAP segundos, por camara.
  2. Normalizar relojes  -> realinea por dias enteros las camaras con la fecha desajustada.
  3. Keeper + miniatura  -> keeper = frame de mayor tamano (bytes); miniatura con sips.
  4. Etiquetado vision   -> 1 llamada claude por rafaga (cacheada); teleobjetivo -> Sonnet, resto -> Haiku.
  5. Fases               -> ventana in-game = rafagas de campo; antes=pre, despues=post.
  6. Escenas + orden     -> funde rafagas contiguas (camara+macro+fase) y ordena cronologicamente.
  7. Salida no destructiva -> manifest.json + thumbs/ + albumes/<fase>/ (symlinks a keepers).

EXIF con exifread vendorizado, miniaturas con sips, etiquetado con claude. Nada de pip/Pillow/internet.
Las fotos originales NUNCA se mueven, renombran ni copian; todo el output va a <carpeta>/_keni_fotos/.

Uso:  python3 keni_fotos.py "<carpeta>" "<partido>" [kickoff HH:MM] [fin HH:MM] [--cap N] [--sin-ia]
"""
import sys, os, re, json, shutil, subprocess, threading
from datetime import datetime
from collections import Counter
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor

sys.path.insert(0, str(Path(__file__).parent / "vendor"))
import exifread

GAP_SEG = 1.0
SCENE_GAP = 600
THUMB_PX = 1280
FOCAL_ACCION = 135
MODELO_BASE = "claude-haiku-4-5"
MODELO_ACCION = "claude-sonnet-4-6"
MAX_IA = 6
MAX_THUMBS = 8
EXT_JPG = (".jpg", ".jpeg")
EXT_RAW = (".cr3", ".cr2", ".nef", ".arw", ".raf", ".dng")
EXT_OK = EXT_JPG + EXT_RAW
MACRO = {"accion": "juego", "celebracion": "juego",
         "aficion": "ambiente", "ambiente": "ambiente", "retrato": "ambiente",
         "detalle": "detalle"}
FASE_ORDEN = {"pre-partido": 0, "in-game": 1, "post-partido": 2}
SALIDA = "_keni_fotos"


# --- EXIF -------------------------------------------------------------------

def _focal(v):
    """FocalLength puede venir '183' o fraccion '1830/10'."""
    if v is None:
        return None
    s = str(v).strip()
    try:
        if "/" in s:
            num, den = s.split("/", 1)
            return round(float(num) / float(den), 1) if float(den) else None
        return float(s)
    except (ValueError, ZeroDivisionError):
        return None


def _ts(fecha):
    """'2026:06:17 20:35:10' -> epoch segundos (precision de segundo, suficiente)."""
    try:
        return datetime.strptime(str(fecha).strip(), "%Y:%m:%d %H:%M:%S").timestamp()
    except (ValueError, TypeError):
        return None


def _exif_exifread(path):
    with open(path, "rb") as fh:
        t = exifread.process_file(fh, details=False)
    dto = t.get("EXIF DateTimeOriginal") or t.get("Image DateTime")
    return {"modelo": str(t.get("Image Model", "")).strip(),
            "lente": str(t.get("EXIF LensModel", "")).strip(),
            "focal_mm": _focal(t.get("EXIF FocalLength")),
            "fecha": str(dto).strip() if dto else None,
            "t": _ts(dto)}


def _exif_mdls(path):
    """Fallback para RAW que exifread no descifra: fecha+focal+modelo via Spotlight."""
    out = subprocess.run(
        ["mdls", "-name", "kMDItemContentCreationDate", "-name", "kMDItemFocalLength",
         "-name", "kMDItemAcquisitionModel", path],
        capture_output=True, text=True).stdout
    info = {"modelo": "", "lente": "", "focal_mm": None, "fecha": None, "t": None}
    m = re.search(r"kMDItemContentCreationDate\s*=\s*(\d{4})-(\d\d)-(\d\d) (\d\d):(\d\d):(\d\d)", out)
    if m:
        info["fecha"] = f"{m[1]}:{m[2]}:{m[3]} {m[4]}:{m[5]}:{m[6]}"
        info["t"] = _ts(info["fecha"])
    m = re.search(r"kMDItemFocalLength\s*=\s*([\d.]+)", out)
    if m:
        info["focal_mm"] = _focal(m[1])
    m = re.search(r'kMDItemAcquisitionModel\s*=\s*"?([^"\n]+)"?', out)
    if m:
        info["modelo"] = m[1].strip()
    return info


def exif_de(path):
    """EXIF por exifread; si no hay fecha (tipico en RAW) cae a Spotlight (mdls)."""
    info = {"modelo": "", "lente": "", "focal_mm": None, "fecha": None, "t": None}
    try:
        info = _exif_exifread(path)
    except Exception:
        pass
    if not info.get("t"):
        m = _exif_mdls(path)
        for k in ("modelo", "lente", "focal_mm", "fecha", "t"):
            if not info.get(k) and m.get(k):
                info[k] = m[k]
    return info


def camara_de(nombre):
    m = re.match(r"([A-Za-z0-9]+?)_?\d+\.", nombre)
    return m.group(1) if m else "?"


# --- Estructura -------------------------------------------------------------

def offsets_reloj(items):
    """Realinea cada camara al dia modal del partido (corrige fecha desajustada,
    conserva la hora del dia). Devuelve {camara: segundos_a_sumar}, dia_modal."""
    por_cam_fecha = {}
    cuenta_dia = Counter()
    for it in items:
        d = datetime.fromtimestamp(it["t"]).date()
        por_cam_fecha.setdefault(it["camara"], Counter())[d] += 1
        cuenta_dia[d] += 1
    dia_modal = cuenta_dia.most_common(1)[0][0]
    off = {}
    for cam, c in por_cam_fecha.items():
        cam_dia = c.most_common(1)[0][0]
        off[cam] = (dia_modal - cam_dia).days * 86400
    return off, dia_modal


def detectar_rafagas(items):
    por_cam = {}
    for it in items:
        por_cam.setdefault(it["camara"], []).append(it)
    rafagas = []
    for lst in por_cam.values():
        lst = sorted(lst, key=lambda x: x["t"])
        cur = [lst[0]]
        for a, b in zip(lst, lst[1:]):
            if b["t"] - a["t"] > GAP_SEG:
                rafagas.append(cur); cur = [b]
            else:
                cur.append(b)
        rafagas.append(cur)
    return rafagas


def macro_de(rafaga):
    """macro = tipo_plano de la IA; sin label (sin-ia / fuera de cap) cae a la focal."""
    tp = (rafaga.get("label") or {}).get("tipo_plano")
    if tp in MACRO:
        return MACRO[tp]
    return "juego" if (rafaga.get("focal_mm") or 0) >= FOCAL_ACCION else "ambiente"


# --- IA + miniaturas --------------------------------------------------------

def thumb_sips(orig, thumb):
    subprocess.run(["sips", "-Z", str(THUMB_PX), str(orig), "--out", str(thumb)],
                   capture_output=True, text=True, timeout=120)
    return thumb.exists()


def etiquetar_ia(thumb, partido, modelo):
    prompt = (
        f"Lee la imagen en {thumb}. Es una foto deportiva del partido '{partido}'.\n"
        "REGLAS DE INTERPRETACION:\n"
        "1) FOCO SELECTIVO: una foto de teleobjetivo suele tener fondo o primer plano "
        "DESENFOCADO. Identifica que esta realmente EN FOCO (nitido). Si el elemento mas "
        "grande o en primer plano esta borroso, NO es el sujeto: el sujeto real es lo nitido "
        "(p.ej. jugadores celebrando al fondo aunque haya un jugador difuminado delante).\n"
        "2) MULTI-SUJETO: si hay varias personas, atribuye cada accion a la persona correcta. "
        "Distingue roles: portero (atajando o LANZANDOSE), defensor/atacante (que pueden "
        "levantar los brazos), arbitro. No asumas que quien levanta los brazos es el portero.\n"
        "Devuelve SOLO un objeto JSON valido (sin markdown) con claves: "
        "deporte; tipo_plano (accion|celebracion|aficion|ambiente|retrato|detalle); "
        "en_foco (frase); primer_plano_desenfocado (true/false); "
        "subjects (array de {rol, equipo, accion}); equipos (array de colores de kit); "
        "jugadores (array de {dorsal,nombre}; nombre SOLO si el dorsal es legible); "
        "sede_o_patrocinadores (array de textos legibles); momento (frase corta); "
        "sujeto_principal (frase corta: lo que esta EN FOCO); tags (array 6-10 keywords minuscula)."
    )
    try:
        r = subprocess.run(["claude", "-p", "--model", modelo, "--output-format", "json",
                            "--allowedTools", "Read"], input=prompt,
                           capture_output=True, text=True, timeout=240)
        env = json.loads(r.stdout)
        txt = re.sub(r"^```(?:json)?|```$", "", env.get("result", "").strip(), flags=re.M).strip()
        return {"label": json.loads(txt), "costo_usd": env.get("total_cost_usd") or 0.0}
    except Exception as e:
        return {"label": {}, "costo_usd": 0.0, "error": str(e)}


def cargar_cache(out):
    """Reusa labels de un manifest previo: {keeper: rafaga} (re-run sin coste)."""
    p = out / "manifest.json"
    if not p.exists():
        return {}
    try:
        m = json.loads(p.read_text())
        return {r["keeper"]: r for e in m.get("escenas", []) for r in e["rafagas"]}
    except Exception:
        return {}


class Progreso:
    """Barra de progreso por etapa, segura entre hilos, con coste IA acumulado."""

    def __init__(self, total, etiqueta):
        self.total, self.etiqueta = total, etiqueta
        self.n, self.costo, self.lock = 0, 0.0, threading.Lock()

    def paso(self, costo=0.0):
        with self.lock:
            self.n += 1; self.costo += costo
            sys.stdout.write(f"\r  {self.etiqueta} {self.n}/{self.total} · ${self.costo:.2f}    ")
            sys.stdout.flush()

    def fin(self):
        if self.total:
            sys.stdout.write("\n")
            sys.stdout.flush()


# --- CLI --------------------------------------------------------------------

def parse_args(argv):
    pos, cap, sin_ia = [], None, False
    i = 1
    while i < len(argv):
        a = argv[i]
        if a == "--sin-ia":
            sin_ia = True
        elif a == "--cap":
            cap = int(argv[i + 1]); i += 1
        elif a.startswith("--cap="):
            cap = int(a.split("=", 1)[1])
        else:
            pos.append(a)
        i += 1
    if not pos:
        sys.exit('Uso: python3 keni_fotos.py "<carpeta>" "<partido>" [kickoff HH:MM] [fin HH:MM] [--cap N] [--sin-ia]')
    carpeta = Path(pos[0]).expanduser()
    partido = pos[1] if len(pos) > 1 else carpeta.name
    kickoff = pos[2] if len(pos) > 2 else None
    fin = pos[3] if len(pos) > 3 else None
    return carpeta, partido, kickoff, fin, cap, sin_ia


def main():
    carpeta, partido, kickoff_hhmm, fin_hhmm, cap, sin_ia = parse_args(sys.argv)
    out = carpeta / SALIDA
    thumbs = out / "thumbs"
    thumbs.mkdir(parents=True, exist_ok=True)
    cache = cargar_cache(out)

    fotos = sorted(p for p in carpeta.iterdir()
                   if p.suffix.lower() in EXT_OK and not p.name.startswith("."))
    print(f"[0] Ingesta EXIF de {len(fotos)} fotos...")
    items, saltadas = [], []
    prog = Progreso(len(fotos), "ingesta")
    with ThreadPoolExecutor(max_workers=MAX_THUMBS) as ex:
        for p, info in zip(fotos, ex.map(lambda q: exif_de(str(q)), fotos)):
            prog.paso()
            if not info.get("t"):
                saltadas.append(p.name); continue
            info["archivo"] = p.name
            info["camara"] = camara_de(p.name)
            info["bytes"] = p.stat().st_size
            items.append(info)
    prog.fin()
    if saltadas:
        print(f"    aviso: {len(saltadas)} foto(s) sin fecha EXIF, saltadas: {', '.join(saltadas[:5])}"
              f"{' ...' if len(saltadas) > 5 else ''}")
    if not items:
        sys.exit("No hay fotos con fecha EXIF legible. Nada que procesar.")

    print("[1] Agrupando en rafagas...")
    grupos = detectar_rafagas(items)
    print(f"    {len(grupos)} rafagas a partir de {len(items)} fotos.")

    print("[2] Normalizando relojes...")
    off, dia_modal = offsets_reloj(items)
    ajustadas = {c: s // 86400 for c, s in off.items() if s}
    print(f"    dia del partido = {dia_modal}. Camaras realineadas (dias): {ajustadas or 'ninguna'}")

    print("[3] Keeper (mayor tamano) por rafaga...")
    rafagas = []
    for frames in grupos:
        keeper = max(frames, key=lambda f: f["bytes"])
        cam = keeper["camara"]; oc = off.get(cam, 0)
        dur = frames[-1]["t"] - frames[0]["t"]
        rafagas.append({
            "id": 0, "camara": cam, "lente": keeper["lente"], "focal_mm": keeper["focal_mm"],
            "fecha_exif": keeper["fecha"], "reloj_ajustado_dias": oc // 86400,
            "t_ini": frames[0]["t"] + oc, "t_fin": frames[-1]["t"] + oc, "n_fotos": len(frames),
            "duracion_s": round(dur, 2),
            "fps_aprox": round((len(frames) - 1) / dur, 1) if dur > 0 else 0.0,
            "keeper": keeper["archivo"], "thumb": "", "frames": [f["archivo"] for f in frames],
            "modelo_ia": MODELO_ACCION if (keeper["focal_mm"] or 0) >= FOCAL_ACCION else MODELO_BASE,
            "label": {}})
    rafagas.sort(key=lambda r: r["t_ini"])
    for i, r in enumerate(rafagas, 1):
        r["id"] = i
        r["thumb"] = f"r{i:03d}_{Path(r['keeper']).stem}.jpg"

    print(f"[4a] Miniaturas (sips) de {len(rafagas)} keepers...")
    prog = Progreso(len(rafagas), "miniaturas")
    def gen_thumb(r):
        th = thumbs / r["thumb"]
        if not th.exists():
            thumb_sips(carpeta / r["keeper"], th)
        prog.paso()
    with ThreadPoolExecutor(max_workers=MAX_THUMBS) as ex:
        list(ex.map(gen_thumb, rafagas))
    prog.fin()

    print("[4b] Etiquetado IA (cache + enrutado por focal)...")
    pendientes = []
    n_cache = 0
    for idx, r in enumerate(rafagas):
        prev = cache.get(r["keeper"])
        if prev and prev.get("label"):
            r["label"] = prev["label"]
            r["modelo_ia"] = prev.get("modelo_ia", r["modelo_ia"])
            n_cache += 1
        elif sin_ia or (cap is not None and idx >= cap):
            r["label"] = {}
        else:
            pendientes.append(r)
    print(f"    {n_cache} desde cache · {len(pendientes)} a etiquetar"
          f"{' · sin-ia (saltado)' if sin_ia else ''}{f' · cap {cap}' if cap is not None else ''}")
    costo, n_ia = 0.0, 0
    if pendientes:
        prog = Progreso(len(pendientes), "etiquetando")
        lock = threading.Lock()
        def etiquetar(r):
            nonlocal costo, n_ia
            res = etiquetar_ia(str(thumbs / r["thumb"]), partido, r["modelo_ia"])
            r["label"] = res.get("label", {})
            with lock:
                costo += res.get("costo_usd") or 0.0
                n_ia += 1
            prog.paso(res.get("costo_usd") or 0.0)
        with ThreadPoolExecutor(max_workers=MAX_IA) as ex:
            list(ex.map(etiquetar, pendientes))
        prog.fin()

    for r in rafagas:
        r["macro"] = macro_de(r)

    print("[5] Detectando fases (ventana in-game)...")
    juego = [r for r in rafagas if r["macro"] in ("juego", "detalle")]
    def hhmm_a_t(hhmm):
        h, mn = map(int, hhmm.split(":"))
        return datetime.combine(dia_modal, datetime.min.time()).replace(hour=h, minute=mn).timestamp()
    g0 = hhmm_a_t(kickoff_hhmm) if kickoff_hhmm else (min(r["t_ini"] for r in juego) if juego else None)
    g1 = hhmm_a_t(fin_hhmm) if fin_hhmm else (max(r["t_fin"] for r in juego) if juego else None)
    for r in rafagas:
        if g0 is None:
            r["fase"] = "in-game"
        elif r["t_fin"] < g0:
            r["fase"] = "pre-partido"
        elif r["t_ini"] > g1:
            r["fase"] = "post-partido"
        else:
            r["fase"] = "in-game"
    if g0:
        print(f"    in-game ~ {datetime.fromtimestamp(g0):%H:%M}-{datetime.fromtimestamp(g1):%H:%M}"
              f" ({'kickoff dado' if kickoff_hhmm else 'auto desde rafagas de campo'})")

    print("[6] Ordenando cronologicamente y agrupando en escenas...")
    rafagas.sort(key=lambda r: r["t_ini"])
    escenas = []
    for r in rafagas:
        if (escenas and escenas[-1]["camara"] == r["camara"] and escenas[-1]["macro"] == r["macro"]
                and escenas[-1]["fase"] == r["fase"] and r["t_ini"] - escenas[-1]["t_fin"] <= SCENE_GAP):
            escenas[-1]["rafagas"].append(r); escenas[-1]["t_fin"] = r["t_fin"]
        else:
            escenas.append({"camara": r["camara"], "macro": r["macro"], "fase": r["fase"],
                            "t_ini": r["t_ini"], "t_fin": r["t_fin"], "rafagas": [r]})
    escenas.sort(key=lambda e: (FASE_ORDEN.get(e["rafagas"][0]["fase"], 1), e["t_ini"]))

    fases_res = Counter(r["fase"] for r in rafagas)
    manifest = {"partido": partido, "dia": str(dia_modal), "fotos": len(items),
                "n_rafagas": len(rafagas), "n_escenas": len(escenas),
                "fases": dict(fases_res), "relojes_ajustados_dias": ajustadas,
                "costo_ia_usd": round(costo, 4), "llamadas_ia": n_ia,
                "escenas": [{"camara": e["camara"], "macro": e["macro"], "fase": e["fase"],
                             "n_rafagas": len(e["rafagas"]),
                             "n_fotos": sum(r["n_fotos"] for r in e["rafagas"]),
                             "rafagas": e["rafagas"]} for e in escenas]}
    (out / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2))

    print("[7] Albumes por fase (symlinks a keepers, no copia originales)...")
    construir_albumes(out, carpeta, rafagas)

    print(f"\nOK · {partido} · {dia_modal}")
    print(f"   {len(items)} fotos · {len(rafagas)} rafagas · {len(escenas)} escenas · fases {dict(fases_res)}")
    if ajustadas:
        print(f"   relojes realineados (dias): {ajustadas}")
    print(f"   IA: {n_ia} llamadas, ${costo:.3f} ({n_cache} reusadas de cache)")
    print(f"   salida: {out}")

    try:
        import ui
        ui.render(manifest, out)
    except Exception as e:
        print("UI pendiente:", e)


def construir_albumes(out, carpeta, rafagas):
    """Organizacion virtual por fase con symlinks al keeper original. Idempotente:
    borra y recrea SOLO la carpeta albumes; nunca toca los originales."""
    alb = out / "albumes"
    if alb.exists():
        shutil.rmtree(alb)
    for r in rafagas:
        d = alb / r["fase"]
        d.mkdir(parents=True, exist_ok=True)
        link = d / r["keeper"]
        target = (carpeta / r["keeper"]).resolve()
        try:
            os.symlink(target, link)
        except FileExistsError:
            pass


if __name__ == "__main__":
    main()
