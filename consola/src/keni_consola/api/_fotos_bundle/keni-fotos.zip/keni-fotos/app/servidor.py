#!/usr/bin/env python3
"""Servidor local de keni-fotos: sirve el SPA y dirige el pipeline.

Solo stdlib. Mantiene UN unico job en memoria. La app web (en app/web/) es quien
guia a la persona: elegir la carpeta del partido, ponerle nombre y pulsar Procesar.
Este servidor expone los endpoints que esa UI necesita:

  GET  /                      -> app/web/index.html (el SPA)
  GET  /assets/*              -> app/web/assets/*
  GET  /api/entorno           -> estado de Claude (instalado / sesion iniciada)
  POST /api/elegir-carpeta    -> selector nativo de carpeta (osascript)
  POST /api/procesar          -> lanza keni_fotos.py en un hilo (un solo job)
  GET  /api/estado            -> fase + lineas de progreso en vivo
  GET  /api/manifest          -> manifest.json del job actual
  GET  /api/thumb/<archivo>   -> miniatura en _keni_fotos/thumbs/
  GET  /api/original/<archivo>-> frame original de la carpeta del partido
  POST /api/copiar            -> copia un original al portapapeles de macOS
  POST /api/borrar            -> manda originales a la Papelera y actualiza el manifest

Arranca en un puerto libre de 127.0.0.1, lo imprime y abre el navegador.
Solo /api/borrar saca fotos de su sitio, y a la Papelera (recuperable); el resto
nunca toca los originales: el pipeline escribe todo en <carpeta>/_keni_fotos/.
"""
import codecs
import json
import mimetypes
import os
import shutil
import socket
import subprocess
import sys
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

RAIZ = Path(__file__).resolve().parent          # app/
WEB = RAIZ / "web"                              # SPA compilado (index.html + assets/)
PIPELINE = RAIZ / "keni_fotos.py"
SALIDA = "_keni_fotos"
MAX_LINEAS = 4000                               # tope de progreso retenido en memoria

# --- Unico job en memoria ---------------------------------------------------
job_lock = threading.Lock()
job = {
    "fase": "idle",        # idle | procesando | listo | error
    "carpeta": None,
    "nombre": None,
    "lineas": [],
    "error": None,
}

# Serializa las ediciones del manifest (borrados) frente al sondeo de lectura.
manifest_lock = threading.Lock()

# --- Entorno de Claude (cacheado) -------------------------------------------
entorno_lock = threading.Lock()
entorno = {
    "comprobado": False,       # ya se corrio la comprobacion al menos una vez
    "comprobando": False,      # hay una comprobacion en curso
    "claude_instalado": False,
    "claude_login": False,
}


def _comprobar_entorno():
    """Comprueba si `claude` esta instalado y con sesion iniciada. El login se
    confirma con una llamada barata (`claude -p OK`): si responde sin error de
    auth, hay sesion. Resultado cacheado; pensado para correr en un hilo."""
    with entorno_lock:
        if entorno["comprobando"]:
            return
        entorno["comprobando"] = True
    instalado = shutil.which("claude") is not None
    login = False
    if instalado:
        try:
            r = subprocess.run(
                ["claude", "-p", "OK", "--output-format", "json"],
                capture_output=True, text=True, timeout=30)
            login = r.returncode == 0
            try:
                login = login and not json.loads(r.stdout).get("is_error", False)
            except Exception:
                pass
        except Exception:
            login = False
    with entorno_lock:
        entorno.update(comprobado=True, comprobando=False,
                       claude_instalado=instalado, claude_login=login)


def _empujar_linea(linea, reemplazar):
    """Anade (o reemplaza la ultima) linea de progreso, de forma segura entre hilos.
    `reemplazar` rehace la ultima linea: asi la barra de progreso (que el pipeline
    redibuja con '\\r') se ve actualizandose en sitio, no como cien lineas nuevas."""
    with job_lock:
        ls = job["lineas"]
        if reemplazar and ls:
            ls[-1] = linea
        else:
            ls.append(linea)
        if len(ls) > MAX_LINEAS:
            del ls[: len(ls) - MAX_LINEAS]


def _correr_pipeline(carpeta, nombre, sin_ia):
    """Ejecuta keni_fotos.py como subproceso y vuelca su stdout (lineas y barras
    de progreso con '\\r') al estado del job. Marca listo/error al terminar."""
    cmd = [sys.executable, str(PIPELINE), carpeta, nombre]
    if sin_ia:
        cmd.append("--sin-ia")
    try:
        proc = subprocess.Popen(
            cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            cwd=str(RAIZ.parent), bufsize=0)
    except Exception as e:
        with job_lock:
            job["fase"] = "error"
            job["error"] = f"No se pudo lanzar el pipeline: {e}"
        return

    decoder = codecs.getincrementaldecoder("utf-8")("replace")
    buf = ""
    reemplazar = False  # la proxima linea reemplaza la ultima (venimos de un '\r')
    for chunk in iter(lambda: proc.stdout.read(1), b""):
        for ch in decoder.decode(chunk):
            if ch in ("\n", "\r"):
                if buf.strip():
                    _empujar_linea(buf, reemplazar)
                buf = ""
                reemplazar = ch == "\r"
            else:
                buf += ch
    if buf.strip():
        _empujar_linea(buf, reemplazar)

    rc = proc.wait()
    out = carpeta_salida(carpeta) / "manifest.json"
    with job_lock:
        if rc == 0 and out.exists():
            job["fase"] = "listo"
        else:
            job["fase"] = "error"
            job["error"] = (
                f"El procesamiento termino con error (codigo {rc})." if rc != 0
                else "Termino sin generar el manifest.")


def carpeta_salida(carpeta):
    return Path(carpeta) / SALIDA


def _ruta_segura(base, nombre):
    """Resuelve `base/nombre` y verifica que NO se sale de `base` (anti path-traversal).
    Devuelve la ruta resuelta o None si escapa de base o no existe como fichero."""
    base = Path(base).resolve()
    objetivo = (base / unquote(nombre)).resolve()
    try:
        objetivo.relative_to(base)
    except ValueError:
        return None
    return objetivo if objetivo.is_file() else None


def _osascript_str(p):
    """Escapa una ruta para incrustarla en una cadena de AppleScript."""
    return str(p).replace("\\", "\\\\").replace('"', '\\"')


def _a_papelera(rutas):
    """Manda los ficheros a la Papelera de macOS via Finder (recuperable)."""
    items = ", ".join(f'POSIX file "{_osascript_str(p)}"' for p in rutas)
    script = f"tell application \"Finder\" to delete {{{items}}}"
    r = subprocess.run(["osascript", "-e", script], capture_output=True, text=True)
    return r.returncode == 0


def _quitar_thumb(thumbs_dir, thumb):
    """Borra (en duro) la miniatura derivada de una rafaga; idempotente."""
    if not thumb:
        return
    try:
        (Path(thumbs_dir) / thumb).unlink()
    except FileNotFoundError:
        pass
    except OSError:
        pass


def _recalcular(manifest):
    """Reconstruye contadores tras un borrado: quita rafagas/escenas vacias y
    recalcula fotos, n_rafagas, n_escenas y fases."""
    escenas = []
    for esc in manifest.get("escenas", []):
        rafs = [r for r in esc.get("rafagas", []) if r.get("frames")]
        if not rafs:
            continue
        for r in rafs:
            r["n_fotos"] = len(r["frames"])
        esc["rafagas"] = rafs
        esc["n_rafagas"] = len(rafs)
        esc["n_fotos"] = sum(r["n_fotos"] for r in rafs)
        escenas.append(esc)
    manifest["escenas"] = escenas
    todas = [r for e in escenas for r in e["rafagas"]]
    manifest["n_rafagas"] = len(todas)
    manifest["n_escenas"] = len(escenas)
    manifest["fotos"] = sum(r["n_fotos"] for r in todas)
    fases = {}
    for r in todas:
        fases[r["fase"]] = fases.get(r["fase"], 0) + 1
    manifest["fases"] = fases
    return manifest


def _aplicar_borrado(carpeta, borrados):
    """Actualiza el manifest tras mandar `borrados` (nombres de frame) a la Papelera:
    quita esos frames de cada rafaga; si una rafaga se queda vacia la elimina (y borra
    su thumb); si cae el keeper elige uno nuevo (mayor tamano) y regenera su thumb."""
    import keni_fotos  # reuso de thumb_sips/THUMB_PX, sin duplicar el pipeline

    carpeta = Path(carpeta)
    out = carpeta_salida(carpeta)
    thumbs_dir = out / "thumbs"
    ruta_m = out / "manifest.json"
    manifest = json.loads(ruta_m.read_text())
    for esc in manifest.get("escenas", []):
        for r in esc.get("rafagas", []):
            frames = r.get("frames", [])
            quedan = [f for f in frames if f not in borrados]
            if len(quedan) == len(frames):
                continue
            if not quedan:
                _quitar_thumb(thumbs_dir, r.get("thumb"))
                r["frames"] = []
                continue
            r["frames"] = quedan
            if r.get("keeper") in borrados:
                nuevo = max(quedan, key=lambda f: (carpeta / f).stat().st_size
                            if (carpeta / f).exists() else 0)
                r["keeper"] = nuevo
                if r.get("thumb"):
                    keni_fotos.thumb_sips(carpeta / nuevo, thumbs_dir / r["thumb"])
    _recalcular(manifest)
    ruta_m.write_text(json.dumps(manifest, ensure_ascii=False, indent=2))


class Handler(BaseHTTPRequestHandler):
    # Silencia el log por peticion (la consola muestra solo lo util).
    def log_message(self, *args):
        pass

    # --- helpers de respuesta ---
    def _json(self, obj, codigo=200):
        cuerpo = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(codigo)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(cuerpo)))
        self.end_headers()
        self.wfile.write(cuerpo)

    def _archivo(self, ruta, content_type=None):
        ruta = Path(ruta)
        if not ruta.is_file():
            self._json({"error": "no encontrado"}, 404)
            return
        ctype = content_type or mimetypes.guess_type(str(ruta))[0] or "application/octet-stream"
        datos = ruta.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(datos)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(datos)

    def _cuerpo_json(self):
        n = int(self.headers.get("Content-Length") or 0)
        if not n:
            return {}
        try:
            return json.loads(self.rfile.read(n).decode("utf-8") or "{}")
        except Exception:
            return {}

    # --- enrutado ---
    def do_GET(self):
        ruta = urlparse(self.path).path
        if ruta == "/" or ruta == "/index.html":
            self._archivo(WEB / "index.html", "text/html; charset=utf-8")
        elif ruta.startswith("/assets/"):
            destino = _ruta_segura(WEB / "assets", ruta[len("/assets/"):])
            self._archivo(destino) if destino else self._json({"error": "no encontrado"}, 404)
        elif ruta == "/api/entorno":
            self._entorno()
        elif ruta == "/api/estado":
            with job_lock:
                self._json(dict(job))
        elif ruta == "/api/manifest":
            with job_lock:
                carpeta = job["carpeta"]
            if not carpeta:
                self._json({"error": "sin job"}, 404)
                return
            with manifest_lock:
                self._archivo(carpeta_salida(carpeta) / "manifest.json",
                              "application/json; charset=utf-8")
        elif ruta.startswith("/api/thumb/"):
            with job_lock:
                carpeta = job["carpeta"]
            if not carpeta:
                self._json({"error": "sin job"}, 404)
                return
            destino = _ruta_segura(carpeta_salida(carpeta) / "thumbs", ruta[len("/api/thumb/"):])
            self._archivo(destino) if destino else self._json({"error": "no encontrado"}, 404)
        elif ruta.startswith("/api/original/"):
            with job_lock:
                carpeta = job["carpeta"]
            if not carpeta:
                self._json({"error": "sin job"}, 404)
                return
            destino = _ruta_segura(carpeta, ruta[len("/api/original/"):])
            self._archivo(destino) if destino else self._json({"error": "no encontrado"}, 404)
        else:
            self._json({"error": "no encontrado"}, 404)

    def do_POST(self):
        ruta = urlparse(self.path).path
        if ruta == "/api/elegir-carpeta":
            self._elegir_carpeta()
        elif ruta == "/api/procesar":
            self._procesar()
        elif ruta == "/api/copiar":
            self._copiar()
        elif ruta == "/api/borrar":
            self._borrar()
        else:
            self._json({"error": "no encontrado"}, 404)

    # --- acciones ---
    def _entorno(self):
        """Estado de Claude (cacheado). Lanza la comprobacion en segundo plano si
        aun no se ha hecho; `?refrescar=1` fuerza una nueva. Nunca bloquea: si esta
        en curso, devuelve comprobando=true y la UI vuelve a preguntar."""
        refrescar = parse_qs(urlparse(self.path).query).get("refrescar")
        with entorno_lock:
            snap = dict(entorno)
        if refrescar or (not snap["comprobado"] and not snap["comprobando"]):
            threading.Thread(target=_comprobar_entorno, daemon=True).start()
            snap = {**snap, "comprobando": True, "comprobado": False}
        self._json(snap)

    def _copiar(self):
        """Copia un original al portapapeles de macOS como imagen JPEG."""
        with job_lock:
            carpeta = job["carpeta"]
        if not carpeta:
            self._json({"error": "sin job"}, 404)
            return
        archivo = (self._cuerpo_json().get("archivo") or "").strip()
        destino = _ruta_segura(carpeta, archivo)
        if not destino:
            self._json({"error": "ruta no valida"}, 400)
            return
        script = f'set the clipboard to (read (POSIX file "{_osascript_str(destino)}") as JPEG picture)'
        r = subprocess.run(["osascript", "-e", script], capture_output=True, text=True)
        if r.returncode != 0:
            self._json({"error": "No se pudo copiar la foto (¿formato no JPEG?)."}, 500)
            return
        self._json({"ok": True})

    def _borrar(self):
        """Manda los originales indicados a la Papelera (recuperable) y actualiza el
        manifest (quita frames, recoloca keepers, recalcula contadores)."""
        with job_lock:
            carpeta = job["carpeta"]
        if not carpeta:
            self._json({"error": "sin job"}, 404)
            return
        nombres = [a for a in (self._cuerpo_json().get("archivos") or []) if isinstance(a, str)]
        if not nombres:
            self._json({"error": "sin archivos"}, 400)
            return
        rutas = []
        for n in nombres:
            destino = _ruta_segura(carpeta, n)
            if not destino:
                self._json({"error": f"ruta no valida: {n}"}, 400)
                return
            rutas.append(destino)
        if not _a_papelera(rutas):
            self._json({"error": "No se pudo mover a la Papelera."}, 500)
            return
        try:
            with manifest_lock:
                _aplicar_borrado(carpeta, set(nombres))
        except Exception as e:
            self._json({"error": f"Fotos en la Papelera, pero fallo el manifest: {e}"}, 500)
            return
        self._json({"ok": True})

    def _elegir_carpeta(self):
        """Selector nativo de macOS. Devuelve la carpeta y un nombre sugerido
        (su basename). Si la persona cancela, {cancelado: true}."""
        try:
            r = subprocess.run(
                ["osascript", "-e",
                 'POSIX path of (choose folder with prompt "Elige la carpeta del partido")'],
                capture_output=True, text=True)
        except Exception as e:
            self._json({"error": str(e)}, 500)
            return
        carpeta = r.stdout.strip().rstrip("/")
        if r.returncode != 0 or not carpeta:
            self._json({"cancelado": True})
            return
        self._json({"carpeta": carpeta, "nombre_sugerido": os.path.basename(carpeta)})

    def _procesar(self):
        with job_lock:
            corriendo = job["fase"] == "procesando"
        if corriendo:
            self._json({"error": "Ya hay un procesamiento en curso."}, 409)
            return
        datos = self._cuerpo_json()
        carpeta = (datos.get("carpeta") or "").strip()
        nombre = (datos.get("nombre") or "").strip()
        sin_ia = bool(datos.get("sin_ia"))
        if not carpeta or not Path(carpeta).is_dir():
            self._json({"error": "La carpeta no existe o no se indico."}, 400)
            return
        if not nombre:
            nombre = os.path.basename(carpeta.rstrip("/"))
        with job_lock:
            job.update(fase="procesando", carpeta=carpeta, nombre=nombre, lineas=[], error=None)
        threading.Thread(
            target=_correr_pipeline, args=(carpeta, nombre, sin_ia), daemon=True).start()
        self._json({"ok": True})


def puerto_libre():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


def main():
    if not (WEB / "index.html").exists():
        print("ERROR: falta el SPA compilado en app/web/.")
        print("Compilalo con:  cd web && npm install && npm run build")
        sys.exit(1)
    puerto = puerto_libre()
    httpd = ThreadingHTTPServer(("127.0.0.1", puerto), Handler)
    url = f"http://127.0.0.1:{puerto}/"
    print("==============================================")
    print("  keni-fotos — app local")
    print("==============================================")
    print(f"  Abierta en: {url}")
    print("  Usa la app en el navegador: elige la carpeta del partido,")
    print("  ponle nombre y pulsa Procesar. Las fotos NO salen de este Mac.")
    print("  Deja esta ventana abierta mientras uses la app; Ctrl+C para cerrar.")
    print("==============================================")
    # Calienta la comprobacion de Claude para que Setup la tenga lista al abrir.
    threading.Thread(target=_comprobar_entorno, daemon=True).start()
    try:
        webbrowser.open(url)
    except Exception:
        pass
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nCerrando keni-fotos. Hasta luego.")
        httpd.shutdown()


if __name__ == "__main__":
    main()
