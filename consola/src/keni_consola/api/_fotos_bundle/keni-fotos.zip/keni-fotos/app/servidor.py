#!/usr/bin/env python3
"""Servidor local de keni-fotos: sirve el SPA y dirige el pipeline.

Solo stdlib. Mantiene UN unico job en memoria. La app web (en app/web/) es quien
guia a la persona: elegir la carpeta del partido, ponerle nombre y pulsar Procesar.
Este servidor expone los endpoints que esa UI necesita:

  GET    /                       -> app/web/index.html (el SPA)
  GET    /assets/*               -> app/web/assets/*
  GET    /api/entorno            -> entorno (Claude instalado/sesion, python3, sips, version)
  POST   /api/elegir-carpeta     -> selector nativo de carpeta (osascript)
  POST   /api/procesar           -> lanza keni_fotos.py en un hilo (un solo job)
  GET    /api/estado             -> fase + lineas de progreso en vivo del job
  GET    /api/galerias           -> registro de partidos procesados (con `disponible`)
  GET    /api/buscar?q=          -> busqueda global en todas las galerias, agrupada por partido
  DELETE /api/galerias/<id>      -> quita una galeria del registro (NO borra fotos)
  GET    /api/manifest?id=       -> manifest.json de esa galeria
  GET    /api/thumb?id=&archivo= -> miniatura en _keni_fotos/thumbs/
  GET    /api/original?id=&archivo= -> frame original de la carpeta del partido
  POST   /api/copiar             -> {id, archivo}: copia un original al portapapeles
  POST   /api/borrar             -> {id, archivos}: a la Papelera + actualiza manifest

El registro de galerias vive fuera del bundle, en
`~/Library/Application Support/keni-fotos/galerias.json`, y mapea id->carpeta.
Arranca en un puerto libre de 127.0.0.1, lo imprime y abre el navegador.
Solo /api/borrar saca fotos de su sitio, y a la Papelera (recuperable); el resto
nunca toca los originales: el pipeline escribe todo en <carpeta>/_keni_fotos/.
"""
import codecs
import hashlib
import json
import mimetypes
import os
import shutil
import socket
import subprocess
import sys
import threading
import unicodedata
import webbrowser
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

RAIZ = Path(__file__).resolve().parent          # app/
WEB = RAIZ / "web"                              # SPA compilado (index.html + assets/)
PIPELINE = RAIZ / "keni_fotos.py"
SALIDA = "_keni_fotos"
MAX_LINEAS = 4000                               # tope de progreso retenido en memoria

# --- Unico job en memoria ---------------------------------------------------
job_lock = threading.Lock()
job = {
    "fase": "idle",        # idle | procesando | listo | error
    "carpeta": None,
    "nombre": None,
    "lineas": [],
    "error": None,
    "galeria_id": None,    # id de la galeria resultante cuando fase == listo
}

# Serializa las ediciones del manifest (borrados) frente al sondeo de lectura.
manifest_lock = threading.Lock()
# Serializa el acceso al registro de galerias en disco.
registro_lock = threading.Lock()

# --- Registro de galerias procesadas ----------------------------------------
# Lista de partidos procesados, persistida fuera del bundle para que sobreviva a
# las actualizaciones de la app y conviva entre varios partidos.
REGISTRO_DIR = Path.home() / "Library" / "Application Support" / "keni-fotos"
REGISTRO = REGISTRO_DIR / "galerias.json"


def galeria_id(carpeta):
    """Id estable de una galeria = hash corto de la ruta absoluta de su carpeta."""
    return hashlib.sha1(str(Path(carpeta).resolve()).encode("utf-8")).hexdigest()[:12]


def _leer_registro():
    try:
        datos = json.loads(REGISTRO.read_text())
        return datos if isinstance(datos, list) else []
    except Exception:
        return []


def _escribir_registro(lista):
    REGISTRO_DIR.mkdir(parents=True, exist_ok=True)
    REGISTRO.write_text(json.dumps(lista, ensure_ascii=False, indent=2))


def _carpeta_de_id(gid):
    """Carpeta del partido a partir de su id (None si no esta o ya no existe)."""
    for e in _leer_registro():
        if e.get("id") == gid:
            c = Path(e.get("carpeta", ""))
            return c if c.is_dir() else None
    return None


def _thumb_primero(manifest):
    for esc in manifest.get("escenas", []):
        for r in esc.get("rafagas", []):
            if r.get("thumb"):
                return r["thumb"]
    return None


# --- Busqueda global (mismo texto buscable que el filtro interno de la galeria) -------
def _normalizar(texto):
    """Minusculas sin acentos, para busquedas tolerantes (espejo de `normalizar` en JS)."""
    base = unicodedata.normalize("NFD", (texto or "").lower())
    return "".join(c for c in base if unicodedata.category(c) != "Mn")


def _texto_buscable(r):
    """Texto plano buscable de una rafaga (tags, sujeto, en_foco, jugadores, equipos, sede,
    fase, macro, camara, momento), normalizado. Espejo de `textoBuscable` en JS."""
    l = r.get("label") or {}
    jugadores = " ".join(
        f"{j.get('dorsal') or ''} {j.get('nombre') or ''}" for j in l.get("jugadores", []))
    sujetos = " ".join(
        f"{s.get('rol', '')} {s.get('equipo', '')} {s.get('accion', '')}" for s in l.get("subjects", []))
    partes = [
        r.get("camara", ""), r.get("fase", ""), r.get("macro", ""),
        l.get("deporte", ""), l.get("tipo_plano", ""), l.get("sujeto_principal", ""),
        l.get("en_foco", ""), l.get("momento", ""),
        sujetos, jugadores,
        " ".join(l.get("equipos", [])),
        " ".join(l.get("sede_o_patrocinadores", [])),
        " ".join(l.get("tags", [])),
    ]
    return _normalizar(" ".join(p for p in partes if p))


def _coincide_busqueda(texto_norm, consulta):
    """Multi-termino AND, sin acentos/case. Consulta vacia = no coincide (no listar todo)."""
    terminos = [t for t in _normalizar(consulta).split() if t]
    return bool(terminos) and all(t in texto_norm for t in terminos)


# Tope de rafagas devueltas por partido en una busqueda (acota el payload; la UI muestra
# `n_coincidencias` para indicar si hay mas de las mostradas).
MAX_RESULTADOS_POR_GALERIA = 60


def _upsert_galeria(carpeta, tocar_fecha=True):
    """Anade/actualiza la entrada de una galeria en el registro a partir de su
    manifest. `tocar_fecha=False` conserva la fecha de proceso (p. ej. tras un
    borrado, que solo cambia contadores). No toca las fotos."""
    carpeta = Path(carpeta)
    m_path = carpeta_salida(carpeta) / "manifest.json"
    if not m_path.exists():
        return
    m = json.loads(m_path.read_text())
    gid = galeria_id(carpeta)
    lista = _leer_registro()
    prev = next((e for e in lista if e.get("id") == gid), None)
    ahora = datetime.now().astimezone().isoformat(timespec="seconds")
    entrada = {
        "id": gid,
        "carpeta": str(carpeta.resolve()),
        "nombre": m.get("partido") or carpeta.name,
        "dia": m.get("dia"),
        "fotos": m.get("fotos", 0),
        "n_escenas": m.get("n_escenas", 0),
        "thumb_rel": _thumb_primero(m),
        "procesado_en": ahora if (tocar_fecha or not prev) else prev.get("procesado_en"),
    }
    lista = [e for e in lista if e.get("id") != gid]
    lista.append(entrada)
    _escribir_registro(lista)


# --- Entorno de Claude (cacheado) -------------------------------------------
entorno_lock = threading.Lock()
entorno = {
    "comprobado": False,       # ya se corrio la comprobacion al menos una vez
    "claude_instalado": False,
    "claude_login": False,
    "python_ok": False,
    "sips_ok": False,
    "version": "",
}


def _version_app():
    """Version de la app desde el fichero VERSION en la raiz (vacia si falta)."""
    try:
        return (RAIZ.parent / "VERSION").read_text().strip()
    except Exception:
        return ""


def _comprobar_entorno():
    """Comprueba, de forma INSTANTANEA y por fichero, el entorno: si `claude` esta
    instalado y con sesion iniciada, y las herramientas del sistema (python3, sips).
    Sin llamadas a `claude -p` (lento y poco fiable en el entorno minimal del .app):
    el login se infiere de las credenciales en disco. Cacheado."""
    home = Path.home()
    instalado = shutil.which("claude") is not None or (home / ".local/bin/claude").exists()
    login = (home / ".claude/oauth-token.json").exists() or (home / ".claude/credentials.json").exists()
    # python3: este servidor ya corre bajo python3; sips: solo en macOS, lo usa el pipeline.
    python_ok = sys.version_info >= (3, 0)
    sips_ok = shutil.which("sips") is not None
    with entorno_lock:
        entorno.update(comprobado=True, claude_instalado=instalado, claude_login=login,
                       python_ok=python_ok, sips_ok=sips_ok, version=_version_app())
    return dict(entorno)


def _empujar_linea(linea, reemplazar):
    """Anade (o reemplaza la ultima) linea de progreso, de forma segura entre hilos.
    `reemplazar` rehace la ultima linea: asi la barra de progreso (que el pipeline
    redibuja con '\\r') se ve actualizandose en sitio, no como cien lineas nuevas."""
    with job_lock:
        ls = job["lineas"]
        if reemplazar and ls:
            ls[-1] = linea
        else:
            ls.append(linea)
        if len(ls) > MAX_LINEAS:
            del ls[: len(ls) - MAX_LINEAS]


def _correr_pipeline(carpeta, nombre, sin_ia):
    """Ejecuta keni_fotos.py como subproceso y vuelca su stdout (lineas y barras
    de progreso con '\\r') al estado del job. Marca listo/error al terminar."""
    cmd = [sys.executable, str(PIPELINE), carpeta, nombre]
    if sin_ia:
        cmd.append("--sin-ia")
    try:
        proc = subprocess.Popen(
            cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            cwd=str(RAIZ.parent), bufsize=0)
    except Exception as e:
        with job_lock:
            job["fase"] = "error"
            job["error"] = f"No se pudo lanzar el pipeline: {e}"
        return

    decoder = codecs.getincrementaldecoder("utf-8")("replace")
    buf = ""
    reemplazar = False  # la proxima linea reemplaza la ultima (venimos de un '\r')
    for chunk in iter(lambda: proc.stdout.read(1), b""):
        for ch in decoder.decode(chunk):
            if ch in ("\n", "\r"):
                if buf.strip():
                    _empujar_linea(buf, reemplazar)
                buf = ""
                reemplazar = ch == "\r"
            else:
                buf += ch
    if buf.strip():
        _empujar_linea(buf, reemplazar)

    rc = proc.wait()
    out = carpeta_salida(carpeta) / "manifest.json"
    if rc == 0 and out.exists():
        gid = None
        try:
            with registro_lock:
                _upsert_galeria(carpeta, tocar_fecha=True)
            gid = galeria_id(carpeta)
        except Exception:
            gid = None
        with job_lock:
            job["fase"] = "listo"
            job["galeria_id"] = gid
    else:
        with job_lock:
            job["fase"] = "error"
            job["error"] = (
                f"El procesamiento termino con error (codigo {rc})." if rc != 0
                else "Termino sin generar el manifest.")


def carpeta_salida(carpeta):
    return Path(carpeta) / SALIDA


def _ruta_segura(base, nombre):
    """Resuelve `base/nombre` y verifica que NO se sale de `base` (anti path-traversal).
    Devuelve la ruta resuelta o None si escapa de base o no existe como fichero."""
    base = Path(base).resolve()
    objetivo = (base / unquote(nombre)).resolve()
    try:
        objetivo.relative_to(base)
    except ValueError:
        return None
    return objetivo if objetivo.is_file() else None


def _osascript_str(p):
    """Escapa una ruta para incrustarla en una cadena de AppleScript."""
    return str(p).replace("\\", "\\\\").replace('"', '\\"')


def _a_papelera(rutas):
    """Manda los ficheros a la Papelera de macOS via Finder (recuperable)."""
    items = ", ".join(f'POSIX file "{_osascript_str(p)}"' for p in rutas)
    script = f"tell application \"Finder\" to delete {{{items}}}"
    r = subprocess.run(["osascript", "-e", script], capture_output=True, text=True)
    return r.returncode == 0


def _quitar_thumb(thumbs_dir, thumb):
    """Borra (en duro) la miniatura derivada de una rafaga; idempotente."""
    if not thumb:
        return
    try:
        (Path(thumbs_dir) / thumb).unlink()
    except FileNotFoundError:
        pass
    except OSError:
        pass


def _recalcular(manifest):
    """Reconstruye contadores tras un borrado: quita rafagas/escenas vacias y
    recalcula fotos, n_rafagas, n_escenas y fases."""
    escenas = []
    for esc in manifest.get("escenas", []):
        rafs = [r for r in esc.get("rafagas", []) if r.get("frames")]
        if not rafs:
            continue
        for r in rafs:
            r["n_fotos"] = len(r["frames"])
        esc["rafagas"] = rafs
        esc["n_rafagas"] = len(rafs)
        esc["n_fotos"] = sum(r["n_fotos"] for r in rafs)
        escenas.append(esc)
    manifest["escenas"] = escenas
    todas = [r for e in escenas for r in e["rafagas"]]
    manifest["n_rafagas"] = len(todas)
    manifest["n_escenas"] = len(escenas)
    manifest["fotos"] = sum(r["n_fotos"] for r in todas)
    fases = {}
    for r in todas:
        fases[r["fase"]] = fases.get(r["fase"], 0) + 1
    manifest["fases"] = fases
    return manifest


def _aplicar_borrado(carpeta, borrados):
    """Actualiza el manifest tras mandar `borrados` (nombres de frame) a la Papelera:
    quita esos frames de cada rafaga; si una rafaga se queda vacia la elimina (y borra
    su thumb); si cae el keeper elige uno nuevo (mayor tamano) y regenera su thumb."""
    import keni_fotos  # reuso de thumb_sips/THUMB_PX, sin duplicar el pipeline

    carpeta = Path(carpeta)
    out = carpeta_salida(carpeta)
    thumbs_dir = out / "thumbs"
    ruta_m = out / "manifest.json"
    manifest = json.loads(ruta_m.read_text())
    for esc in manifest.get("escenas", []):
        for r in esc.get("rafagas", []):
            frames = r.get("frames", [])
            quedan = [f for f in frames if f not in borrados]
            if len(quedan) == len(frames):
                continue
            if not quedan:
                _quitar_thumb(thumbs_dir, r.get("thumb"))
                r["frames"] = []
                continue
            r["frames"] = quedan
            if r.get("keeper") in borrados:
                nuevo = max(quedan, key=lambda f: (carpeta / f).stat().st_size
                            if (carpeta / f).exists() else 0)
                r["keeper"] = nuevo
                if r.get("thumb"):
                    keni_fotos.thumb_sips(carpeta / nuevo, thumbs_dir / r["thumb"])
    _recalcular(manifest)
    ruta_m.write_text(json.dumps(manifest, ensure_ascii=False, indent=2))


class Handler(BaseHTTPRequestHandler):
    # Silencia el log por peticion (la consola muestra solo lo util).
    def log_message(self, *args):
        pass

    # --- helpers de respuesta ---
    def _json(self, obj, codigo=200):
        cuerpo = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(codigo)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(cuerpo)))
        self.end_headers()
        self.wfile.write(cuerpo)

    def _archivo(self, ruta, content_type=None):
        ruta = Path(ruta)
        if not ruta.is_file():
            self._json({"error": "no encontrado"}, 404)
            return
        ctype = content_type or mimetypes.guess_type(str(ruta))[0] or "application/octet-stream"
        datos = ruta.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(datos)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(datos)

    def _cuerpo_json(self):
        n = int(self.headers.get("Content-Length") or 0)
        if not n:
            return {}
        try:
            return json.loads(self.rfile.read(n).decode("utf-8") or "{}")
        except Exception:
            return {}

    def _query(self):
        return parse_qs(urlparse(self.path).query)

    def _carpeta_de_query(self):
        """Carpeta del partido a partir de `?id=` (None si falta o no existe)."""
        gid = self._query().get("id", [None])[0]
        return _carpeta_de_id(gid) if gid else None

    # --- enrutado ---
    def do_GET(self):
        ruta = urlparse(self.path).path
        if ruta == "/" or ruta == "/index.html":
            self._archivo(WEB / "index.html", "text/html; charset=utf-8")
        elif ruta.startswith("/assets/"):
            destino = _ruta_segura(WEB / "assets", ruta[len("/assets/"):])
            self._archivo(destino) if destino else self._json({"error": "no encontrado"}, 404)
        elif ruta == "/api/entorno":
            self._entorno()
        elif ruta == "/api/estado":
            with job_lock:
                self._json(dict(job))
        elif ruta == "/api/galerias":
            with registro_lock:
                lista = sorted(_leer_registro(), key=lambda e: e.get("procesado_en") or "", reverse=True)
            # `disponible`: ¿su carpeta sigue accesible? (disco desconectado, carpeta movida).
            # No disponible NO se quita del registro; solo se marca para que la UI lo refleje.
            for e in lista:
                e["disponible"] = Path(e.get("carpeta", "")).is_dir()
            self._json(lista)
        elif ruta == "/api/buscar":
            self._buscar()
        elif ruta == "/api/manifest":
            carpeta = self._carpeta_de_query()
            if not carpeta:
                self._json({"error": "galeria no encontrada"}, 404)
                return
            with manifest_lock:
                self._archivo(carpeta_salida(carpeta) / "manifest.json",
                              "application/json; charset=utf-8")
        elif ruta == "/api/thumb":
            carpeta = self._carpeta_de_query()
            archivo = self._query().get("archivo", [None])[0]
            destino = _ruta_segura(carpeta_salida(carpeta) / "thumbs", archivo) if (carpeta and archivo) else None
            self._archivo(destino) if destino else self._json({"error": "no encontrado"}, 404)
        elif ruta == "/api/original":
            carpeta = self._carpeta_de_query()
            archivo = self._query().get("archivo", [None])[0]
            destino = _ruta_segura(carpeta, archivo) if (carpeta and archivo) else None
            self._archivo(destino) if destino else self._json({"error": "no encontrado"}, 404)
        else:
            self._json({"error": "no encontrado"}, 404)

    def do_DELETE(self):
        ruta = urlparse(self.path).path
        if ruta.startswith("/api/galerias/"):
            gid = ruta[len("/api/galerias/"):]
            with registro_lock:
                lista = _leer_registro()
                nueva = [e for e in lista if e.get("id") != gid]
                _escribir_registro(nueva)
            self._json({"ok": True, "borrado": len(lista) != len(nueva)})
        else:
            self._json({"error": "no encontrado"}, 404)

    def do_POST(self):
        ruta = urlparse(self.path).path
        if ruta == "/api/elegir-carpeta":
            self._elegir_carpeta()
        elif ruta == "/api/procesar":
            self._procesar()
        elif ruta == "/api/copiar":
            self._copiar()
        elif ruta == "/api/borrar":
            self._borrar()
        else:
            self._json({"error": "no encontrado"}, 404)

    # --- acciones ---
    def _entorno(self):
        """Estado de Claude. La comprobacion es por fichero (instantanea): se calcula
        si aun no esta cacheada o si `?refrescar=1`. Devuelve siempre comprobado=true."""
        refrescar = self._query().get("refrescar")
        with entorno_lock:
            listo = entorno["comprobado"]
        if refrescar or not listo:
            self._json(_comprobar_entorno())
            return
        with entorno_lock:
            self._json(dict(entorno))

    def _buscar(self):
        """Busqueda GLOBAL en TODAS las galerias del registro: recorre cada manifest
        disponible y devuelve, AGRUPADAS por partido, las rafagas que coinciden con `q`
        (mismo texto buscable que el filtro interno). Las galerias no disponibles (carpeta
        ausente) se omiten: no se puede leer su manifest."""
        q = (self._query().get("q", [""])[0] or "").strip()
        if not q:
            self._json({"q": "", "total": 0, "grupos": []})
            return
        with registro_lock:
            registro = sorted(
                _leer_registro(), key=lambda e: e.get("procesado_en") or "", reverse=True)
        grupos = []
        total = 0
        for e in registro:
            carpeta = Path(e.get("carpeta", ""))
            if not carpeta.is_dir():
                continue
            m_path = carpeta_salida(carpeta) / "manifest.json"
            if not m_path.exists():
                continue
            try:
                m = json.loads(m_path.read_text())
            except Exception:
                continue
            encontradas = []
            for esc in m.get("escenas", []):
                for r in esc.get("rafagas", []):
                    if _coincide_busqueda(_texto_buscable(r), q):
                        encontradas.append({
                            "id": r.get("id"),
                            "thumb": r.get("thumb"),
                            "keeper": r.get("keeper"),
                            "fase": r.get("fase"),
                            "camara": r.get("camara"),
                            "macro": r.get("macro"),
                            "n_fotos": r.get("n_fotos", len(r.get("frames", []))),
                            "en_foco": (r.get("label") or {}).get("en_foco", ""),
                        })
            if encontradas:
                total += len(encontradas)
                grupos.append({
                    "galeria_id": e.get("id"),
                    "nombre": e.get("nombre"),
                    "dia": e.get("dia"),
                    "n_coincidencias": len(encontradas),
                    "rafagas": encontradas[:MAX_RESULTADOS_POR_GALERIA],
                })
        self._json({"q": q, "total": total, "grupos": grupos})

    def _copiar(self):
        """Copia un original (por id de galeria + archivo) al portapapeles como JPEG."""
        datos = self._cuerpo_json()
        carpeta = _carpeta_de_id(datos.get("id"))
        if not carpeta:
            self._json({"error": "galeria no encontrada"}, 404)
            return
        archivo = (datos.get("archivo") or "").strip()
        destino = _ruta_segura(carpeta, archivo)
        if not destino:
            self._json({"error": "ruta no valida"}, 400)
            return
        script = f'set the clipboard to (read (POSIX file "{_osascript_str(destino)}") as JPEG picture)'
        r = subprocess.run(["osascript", "-e", script], capture_output=True, text=True)
        if r.returncode != 0:
            self._json({"error": "No se pudo copiar la foto (¿formato no JPEG?)."}, 500)
            return
        self._json({"ok": True})

    def _borrar(self):
        """Manda originales (por id de galeria) a la Papelera (recuperable) y actualiza el
        manifest (quita frames, recoloca keepers, recalcula contadores) y el registro."""
        datos = self._cuerpo_json()
        carpeta = _carpeta_de_id(datos.get("id"))
        if not carpeta:
            self._json({"error": "galeria no encontrada"}, 404)
            return
        nombres = [a for a in (datos.get("archivos") or []) if isinstance(a, str)]
        if not nombres:
            self._json({"error": "sin archivos"}, 400)
            return
        rutas = []
        for n in nombres:
            destino = _ruta_segura(carpeta, n)
            if not destino:
                self._json({"error": f"ruta no valida: {n}"}, 400)
                return
            rutas.append(destino)
        if not _a_papelera(rutas):
            self._json({"error": "No se pudo mover a la Papelera."}, 500)
            return
        try:
            with manifest_lock:
                _aplicar_borrado(carpeta, set(nombres))
            with registro_lock:
                _upsert_galeria(carpeta, tocar_fecha=False)
        except Exception as e:
            self._json({"error": f"Fotos en la Papelera, pero fallo el manifest: {e}"}, 500)
            return
        self._json({"ok": True})

    def _elegir_carpeta(self):
        """Selector nativo de macOS. Devuelve la carpeta y un nombre sugerido
        (su basename). Si la persona cancela, {cancelado: true}."""
        try:
            r = subprocess.run(
                ["osascript", "-e",
                 'POSIX path of (choose folder with prompt "Elige la carpeta del partido")'],
                capture_output=True, text=True)
        except Exception as e:
            self._json({"error": str(e)}, 500)
            return
        carpeta = r.stdout.strip().rstrip("/")
        if r.returncode != 0 or not carpeta:
            self._json({"cancelado": True})
            return
        self._json({"carpeta": carpeta, "nombre_sugerido": os.path.basename(carpeta)})

    def _procesar(self):
        with job_lock:
            corriendo = job["fase"] == "procesando"
        if corriendo:
            self._json({"error": "Ya hay un procesamiento en curso."}, 409)
            return
        datos = self._cuerpo_json()
        carpeta = (datos.get("carpeta") or "").strip()
        nombre = (datos.get("nombre") or "").strip()
        sin_ia = bool(datos.get("sin_ia"))
        if not carpeta or not Path(carpeta).is_dir():
            self._json({"error": "La carpeta no existe o no se indico."}, 400)
            return
        if not nombre:
            nombre = os.path.basename(carpeta.rstrip("/"))
        with job_lock:
            job.update(fase="procesando", carpeta=carpeta, nombre=nombre,
                       lineas=[], error=None, galeria_id=None)
        threading.Thread(
            target=_correr_pipeline, args=(carpeta, nombre, sin_ia), daemon=True).start()
        self._json({"ok": True})


def puerto_libre():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


def main():
    if not (WEB / "index.html").exists():
        print("ERROR: falta el SPA compilado en app/web/.")
        print("Compilalo con:  cd web && npm install && npm run build")
        sys.exit(1)
    puerto = puerto_libre()
    httpd = ThreadingHTTPServer(("127.0.0.1", puerto), Handler)
    url = f"http://127.0.0.1:{puerto}/"
    print("==============================================")
    print("  keni-fotos — app local")
    print("==============================================")
    print(f"  Abierta en: {url}")
    print("  Usa la app en el navegador: elige la carpeta del partido,")
    print("  ponle nombre y pulsa Procesar. Las fotos NO salen de este Mac.")
    print("  Deja esta ventana abierta mientras uses la app; Ctrl+C para cerrar.")
    print("==============================================")
    # Comprobacion de Claude (instantanea, por fichero): la dejamos cacheada al abrir.
    _comprobar_entorno()
    try:
        webbrowser.open(url)
    except Exception:
        pass
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nCerrando keni-fotos. Hasta luego.")
        httpd.shutdown()


if __name__ == "__main__":
    main()
