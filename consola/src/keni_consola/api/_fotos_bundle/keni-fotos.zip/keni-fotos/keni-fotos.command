#!/bin/bash
# keni-fotos — lanzador doble-clic para el equipo de fotografia (Claro Sports / UnoTV).
# Doble clic en Finder: elige la carpeta del partido, pon el nombre y se genera la galeria.
# 100% local. No sube nada. No toca tus fotos: todo va a una subcarpeta _keni_fotos.

# --- Carpeta del propio .command (soporta espacios) ---
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP="$DIR/app"

# --- Quitar la cuarentena de Gatekeeper si llego por AirDrop/drive (no-op si no aplica) ---
xattr -dr com.apple.quarantine "$DIR" 2>/dev/null || true

# --- claude/python suelen vivir fuera del PATH minimo de un doble-clic ---
export PATH="$HOME/.local/bin:$HOME/.claude/local:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:$PATH"

# --- Mostrar un error visible (ventana + terminal) y salir ---
morir() {
  echo ""
  echo "ERROR: $1"
  osascript -e "display dialog \"$1\" with title \"keni-fotos\" buttons {\"Cerrar\"} default button 1 with icon stop" >/dev/null 2>&1
  echo ""
  echo "Pulsa Enter para cerrar esta ventana."
  read -r _
  exit 1
}

echo "=============================================="
echo "  keni-fotos — galeria de partido (local)"
echo "=============================================="
echo ""

# --- Requisito: python3 ---
if ! command -v python3 >/dev/null 2>&1; then
  echo "Falta python3. Abriendo el instalador de Herramientas de Linea de Comandos..."
  xcode-select --install >/dev/null 2>&1 || true
  morir "Falta python3 en este Mac. Se abrio el instalador de Apple (Herramientas de Linea de Comandos). Instalalo, espera a que termine y vuelve a abrir keni-fotos."
fi

# --- Requisito: claude (Claude Code logueado) ---
if ! command -v claude >/dev/null 2>&1; then
  morir "No encuentro 'claude' (Claude Code). Instalalo e inicia sesion, luego vuelve a abrir keni-fotos. (El etiquetado de fotos usa tu propia sesion de Claude.)"
fi

# --- Carpeta del partido: argumento (arrastrar) o selector nativo ---
CARPETA="$1"
if [ -z "$CARPETA" ]; then
  CARPETA="$(osascript -e 'POSIX path of (choose folder with prompt "Elige la carpeta del partido (en el drive)")' 2>/dev/null)"
  if [ -z "$CARPETA" ]; then
    echo "Cancelado. No se eligio carpeta."
    exit 0
  fi
fi
# Normalizar: quitar la barra final que devuelve AppleScript
CARPETA="${CARPETA%/}"
[ -d "$CARPETA" ] || morir "La carpeta no existe: $CARPETA"

# --- Nombre del partido ---
NOMBRE="$(osascript -e 'text returned of (display dialog "Nombre del partido:" default answer "Partido" with title "keni-fotos")' 2>/dev/null)"
if [ -z "$NOMBRE" ]; then
  NOMBRE="$(basename "$CARPETA")"
fi

# --- ¿Etiquetar con IA ahora? En partidos grandes (miles de fotos) tarda y consume
#     uso de tu Claude. "Solo estructura" es instantaneo y gratis: agrupa y divide en
#     fases sin etiquetar; puedes volver a correrlo luego para etiquetar (reusa lo hecho). ---
FLAGS=""
MODO="$(osascript -e 'button returned of (display dialog "¿Etiquetar las fotos con IA ahora?\n\n• Con IA: describe cada rafaga (tarda y usa tu Claude en partidos grandes).\n• Solo estructura: instantaneo y gratis (agrupa + fases, sin etiquetas). Puedes etiquetar despues." with title "keni-fotos" buttons {"Solo estructura", "Etiquetar con IA"} default button "Etiquetar con IA")' 2>/dev/null)"
if [ "$MODO" = "Solo estructura" ]; then
  FLAGS="--sin-ia"
fi

echo "Carpeta : $CARPETA"
echo "Partido : $NOMBRE"
echo "Modo    : ${FLAGS:-con IA}"
echo ""
echo "Procesando... (puede tardar; el etiquetado con IA consume uso de tu Claude en partidos grandes)"
echo "----------------------------------------------"
echo ""

# --- Pipeline (la ventana de Terminal muestra el progreso en vivo) ---
python3 "$APP/keni_fotos.py" "$CARPETA" "$NOMBRE" $FLAGS
RC=$?

echo ""
echo "----------------------------------------------"
INDEX="$CARPETA/_keni_fotos/index.html"
if [ $RC -ne 0 ]; then
  morir "El procesamiento termino con error (codigo $RC). Mira el detalle arriba en esta ventana y compartelo con el equipo de keni."
fi
if [ ! -f "$INDEX" ]; then
  morir "Termino sin generar la galeria ($INDEX no existe). Compartelo con el equipo de keni."
fi

# --- Servir la galeria por http local ---
# El SPA (React/Vite/shadcn) hace fetch('./manifest.json') y el visor carga los
# originales desde la carpeta padre, asi que NO vale abrir el index como file://:
# servimos la carpeta del partido y abrimos /_keni_fotos/index.html en el navegador.
PORT="$(python3 -c 'import socket;s=socket.socket();s.bind(("127.0.0.1",0));p=s.getsockname()[1];s.close();print(p)' 2>/dev/null)"
[ -z "$PORT" ] && PORT=8770
python3 -m http.server "$PORT" --directory "$CARPETA" >/dev/null 2>&1 &
SRV=$!
trap 'kill $SRV 2>/dev/null' EXIT INT TERM
sleep 1
URL="http://localhost:$PORT/_keni_fotos/index.html"
echo "Listo. Abriendo la galeria:"
echo "  $URL"
open "$URL"
echo ""
echo "La galeria corre en un servidor local mientras esta ventana este abierta."
echo "Cuando termines, cierra esta ventana (o pulsa Ctrl+C) para detenerlo."
wait $SRV
