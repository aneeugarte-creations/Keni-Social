#!/bin/bash
# keni-fotos — lanzador doble-clic para el equipo de fotografia (Claro Sports / UnoTV).
# Doble clic en Finder: compila el SPA (si hay Node) y abre la app en el navegador.
# La app guia el resto: elegir carpeta del partido, ponerle nombre y pulsar Procesar.
# 100% local. No sube nada. No toca tus fotos: todo va a una subcarpeta _keni_fotos.

# --- Carpeta del propio .command (soporta espacios) ---
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP="$DIR/app"

# --- Quitar la cuarentena de Gatekeeper si llego por AirDrop/drive (no-op si no aplica) ---
xattr -dr com.apple.quarantine "$DIR" 2>/dev/null || true

# --- claude/python/node suelen vivir fuera del PATH minimo de un doble-clic ---
export PATH="$HOME/.local/bin:$HOME/.claude/local:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:$PATH"

# --- Mostrar un error visible (ventana + terminal) y salir ---
morir() {
  echo ""
  echo "ERROR: $1"
  osascript -e "display dialog \"$1\" with title \"keni-fotos\" buttons {\"Cerrar\"} default button 1 with icon stop" >/dev/null 2>&1
  echo ""
  echo "Pulsa Enter para cerrar esta ventana."
  read -r _
  exit 1
}

echo "=============================================="
echo "  keni-fotos — galeria de partido (local)"
echo "=============================================="
echo ""

# --- Requisito: python3 ---
if ! command -v python3 >/dev/null 2>&1; then
  echo "Falta python3. Abriendo el instalador de Herramientas de Linea de Comandos..."
  xcode-select --install >/dev/null 2>&1 || true
  morir "Falta python3 en este Mac. Se abrio el instalador de Apple (Herramientas de Linea de Comandos). Instalalo, espera a que termine y vuelve a abrir keni-fotos."
fi

# --- Aviso (no bloqueante): claude para el etiquetado con IA ---
if ! command -v claude >/dev/null 2>&1; then
  echo "Aviso: no encuentro 'claude' (Claude Code). La app funcionara en modo 'solo estructura'."
  echo "       Para etiquetar con IA, instala Claude Code e inicia sesion."
  echo ""
fi

# --- Compilar el SPA si hay Node; si no, usar el ya compilado en app/web/ ---
if command -v node >/dev/null 2>&1; then
  echo "Node detectado. Compilando la interfaz..."
  ( cd "$DIR/web" && npm install && npm run build ) || morir "Fallo al compilar la interfaz. Compartelo con el equipo de keni."
  echo ""
else
  echo "Sin Node: uso la interfaz ya compilada que viene en el paquete."
  echo ""
fi

[ -f "$APP/web/index.html" ] || morir "Falta la interfaz compilada (app/web/index.html). Compartelo con el equipo de keni."

# --- Lanzar la app (abre el navegador solo) ---
echo "Abriendo la app en el navegador..."
echo "Deja esta ventana abierta mientras uses la app. Ctrl+C para cerrar."
echo "----------------------------------------------"
echo ""
python3 "$APP/servidor.py"
